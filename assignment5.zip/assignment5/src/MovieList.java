/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
/**
 *
 * @author user
 */
public class MovieList {

    // ======= Instance Variables =======
    private Movie head;   // first movie
    private Movie tail;   // last movie
    private int count;    // total number of movies

    // ======= Constructor =======
    public MovieList() {
        head = null;
        tail = null;
        count = 0;
    }

    // ======= (A) isEmpty =======
    public boolean isEmpty() {
        return head == null;   // same idea as slides' isEmpty()
    }

    // ======= (B) getMovieAt(index) =======
    // 0-based index. Returns null if out of bounds.
    public Movie getMovieAt(int index) {
        if (index < 0 || index >= count) return null;
        Movie current = head;
        int i = 0;
        while (current != null && i < index) {
            current = current.getNext();
            i++;
        }
        return current; // either the node at index or null
    }

    // ======= (C) updateMovieRating(movieID, newRating) =======
    public void updateMovieRating(String movieID, double newRating) {
        Movie current = head;
        while (current != null && !current.getMid().equals(movieID)) {
            current = current.getNext();
        }
        if (current != null) {
            current.setRating(newRating);
        }
    }

    // ======= (Helper) append at end (standard insertion) =======
    // Simple insertLast like in slides (case empty / non-empty)
    public void addLast(Movie m) {
        if (m == null) return;
        m.setNext(null);
        m.setPrev(null);
        if (isEmpty()) {
            head = m;
            tail = m;
        } else {
            tail.setNext(m);
            m.setPrev(tail);
            tail = m;
        }
        count++;
    }

    // ======= (D) addMovieSortedByRating (descending) =======
    // Keep list sorted by rating: highest first.
    public void addMovieSortedByRating(Movie m) {
        if (m == null) return;

        // If list empty, insert as first
        if (isEmpty()) {
            head = m;
            tail = m;
            m.setNext(null);
            m.setPrev(null);
            count = 1;
            return;
        }

        // If should go to front
        if (m.getRating() >= head.getRating()) {
            m.setNext(head);
            m.setPrev(null);
            head.setPrev(m);
            head = m;
            count++;
            return;
        }

        // Otherwise, find position
        Movie current = head;
        while (current != null && current.getRating() >= m.getRating()) {
            current = current.getNext();
        }

        if (current == null) {
            // goes to end
            m.setPrev(tail);
            m.setNext(null);
            tail.setNext(m);
            tail = m;
            count++;
        } else {
            // insert before current
            Movie prev = current.getPrev();
            m.setPrev(prev);
            m.setNext(current);
            prev.setNext(m);
            current.setPrev(m);
            count++;
        }
    }

    // ======= (E) removeFirst =======
    // Removes first movie and returns its info (toString);
    // If empty, returns a message.
    public String removeFirst() {
        if (isEmpty()) {
            return "Movie list is empty";
        }
        Movie removed = head;
        if (head == tail) { // only one node
            head = null;
            tail = null;
        } else {
            head = head.getNext();
            head.setPrev(null);
            removed.setNext(null);
        }
        count--;
        return "Removed:\n" + removed.toString();
    }

    // ======= (F) searchByGenre =======
    public ArrayList<Movie> searchByGenre(String genre) {
        ArrayList<Movie> result = new ArrayList<Movie>();
        if (genre == null) return result;

        Movie current = head;
        while (current != null) {
            if (current.getGenre() != null &&
                current.getGenre().equalsIgnoreCase(genre)) {
                result.add(current);
            }
            current = current.getNext();
        }
        return result;
    }

    // ======= (G) searchByRatingRange =======
    // inclusive range
    public Movie[] searchByRatingRange(double minRating, double maxRating) {
        // First pass: count matches
        int matches = 0;
        Movie current = head;
        while (current != null) {
            double r = current.getRating();
            if (r >= minRating && r <= maxRating) {
                matches++;
            }
            current = current.getNext();
        }

        // Second pass: fill array
        Movie[] arr = new Movie[matches];
        int i = 0;
        current = head;
        while (current != null) {
            double r = current.getRating();
            if (r >= minRating && r <= maxRating) {
                arr[i] = current;
                i++;
            }
            current = current.getNext();
        }
        return arr;
    }

    // ======= (H) moveHighestRatedToFront =======
    public void moveHighestRatedToFront() {
        if (isEmpty() || head == tail) return;

        // Find max node
        Movie maxNode = head;
        Movie current = head.getNext();
        while (current != null) {
            if (current.getRating() > maxNode.getRating()) {
                maxNode = current;
            }
            current = current.getNext();
        }

        // Already at front
        if (maxNode == head) return;

        // Unlink maxNode
        Movie p = maxNode.getPrev();
        Movie n = maxNode.getNext();

        if (p != null) p.setNext(n);
        if (n != null) n.setPrev(p);
        if (maxNode == tail) {
            tail = p; // if it was last, update tail
        }

        // Move to front
        maxNode.setPrev(null);
        maxNode.setNext(head);
        head.setPrev(maxNode);
        head = maxNode;
    }

    // ======= (I) reverseList (in-place) =======
    public void reverseList() {
        if (isEmpty() || head == tail) return;

        Movie current = head;
        // Swap next/prev for every node
        while (current != null) {
            Movie tmp = current.getNext();
            // swap pointers
            Movie oldNext = current.getNext();
            Movie oldPrev = current.getPrev();
            current.setNext(oldPrev);
            current.setPrev(oldNext);

            current = tmp; // advance using original next
        }

        // Swap head and tail
        Movie tmpHead = head;
        head = tail;
        tail = tmpHead;
    }

    // ======= (Extra) size =======
    public int size() {
        return count;
    }

    // ======= (Extra) print =======
    // Simple traversal print like slides
    public void print() {
        if (isEmpty()) {
            System.out.println("Movie list is empty");
            return;
        }
        Movie current = head;
        while (current != null) {
            System.out.println(current.toString());
            System.out.println("--------------------");
            current = current.getNext();
        }
    }
}
