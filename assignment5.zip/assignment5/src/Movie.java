/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Movie {
    
    private String mid;
    private String title;
    private String genre;
    private double rating;
    private int releaseYear;
    private Movie next;
    private Movie prev;
    
    public Movie(String mid, String title, String genre, double rating, int releaseYear){ 
        this.mid = mid;
        this.title = title;
        this.genre = genre;
        this.rating = rating;
        this.releaseYear = releaseYear;
        this.next = null;
        this.prev = null;
        
    }
    
    public String getMid(){ return mid;}
    public String getTitle(){ return title;}
    public String getGenre(){ return genre;}
    public double getRating(){ return rating;}
    public int getReleaseYear(){ return releaseYear;}
    public Movie getNext(){ return next;}
    public Movie getPrev(){ return prev;}
    
    public void setMid(String mid){ this.mid = mid;}
    public void setTitle(String title){ this.title = title;}
    public void setGenre(String genre){ this.genre = genre;}
    public void setRating(double rating){ this.rating = rating;}
    public void setReleaseYear(int releaseYear){ this.releaseYear = releaseYear;}
    public void setNext(Movie next){ this.next = next;}
    public void setPrev(Movie prev){ this.prev = prev;}
    
    public String toString(){
        return "Movie id: " + mid 
        + "\nTitle: " + title
        + "\nGenre: " + genre
        + "\nRating: " + rating
        + "\nreleaseYear: " + releaseYear;
    }

}
