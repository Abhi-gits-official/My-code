/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
/**
 *
 * @author user
 */
public class TestMovieList {

    public static void main(String[] args) {

        // 1) Create a MovieList object
        MovieList list = new MovieList();

        // 2) Insert 3 movies using addMovieSortedByRating (descending by rating)
        Movie m1 = new Movie("M101", "Inception", "Action", 8.8, 2010);
        Movie m2 = new Movie("M102", "The Intouchables", "Drama", 8.5, 2011);
        Movie m3 = new Movie("M103", "The Dark Knight", "Action", 9.0, 2008);

        list.addMovieSortedByRating(m1);
        list.addMovieSortedByRating(m2);
        list.addMovieSortedByRating(m3);

        // 3) Insert 2 movies at the end using standard insertion
        Movie m4 = new Movie("M104", "Toy Story", "Comedy", 8.3, 1995);
        Movie m5 = new Movie("M105", "Interstellar", "Drama", 8.6, 2014);

        list.addLast(m4);
        list.addLast(m5);

        // 4) Print the full list
        System.out.println("=== Full Movie List (after inserts) ===");
        list.print();

        // 5) Update the rating of a specific movie
        System.out.println("=== Update rating of M102 to 9.1 ===");
        list.updateMovieRating("M102", 9.1);
        list.print();

        // 6) Search and print all movies of a specific genre
        System.out.println("=== Search by genre: Action ===");
        ArrayList<Movie> actionMovies = list.searchByGenre("Action");
        if (actionMovies.size() == 0) {
            System.out.println("No movies found for genre 'Action'");
        } else {
            for (int i = 0; i < actionMovies.size(); i++) {
                System.out.println(actionMovies.get(i).toString());
                System.out.println("--------------------");
            }
        }

        // 7) Print all movies with ratings between 7.0 and 9.5 (inclusive)
        System.out.println("=== Movies with rating between 7.0 and 9.5 ===");
        Movie[] rangeMovies = list.searchByRatingRange(7.0, 9.5);
        if (rangeMovies.length == 0) {
            System.out.println("No movies found in the given rating range.");
        } else {
            for (int i = 0; i < rangeMovies.length; i++) {
                System.out.println(rangeMovies[i].toString());
                System.out.println("--------------------");
            }
        }

        // 8) Remove the first movie
        System.out.println("=== Remove first movie ===");
        String removedInfo = list.removeFirst();
        System.out.println(removedInfo);
        System.out.println("=== List after removing first ===");
        list.print();

        // 9) Move the highest-rated movie to the front
        System.out.println("=== Move highest-rated movie to front ===");
        list.moveHighestRatedToFront();
        list.print();

        // 10) Reverse the list and print it
        System.out.println("=== Reverse the list ===");
        list.reverseList();
        list.print();

        // Optional: show size
        System.out.println("Total movies in list: " + list.size());
    }
}
